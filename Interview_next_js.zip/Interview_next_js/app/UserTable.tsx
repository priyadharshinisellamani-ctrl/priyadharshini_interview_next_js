import Link from "next/link";
import { User } from "./user";


interface Props {
  users: User[];
}

export default function UserTable({ users }: Props) {
  return (
    <table className="w-full border border-gray-300">
      <thead className="bg-gray-100">
        <tr>
          <th className="border p-2">Name</th>
          <th className="border p-2">Email</th>
          <th className="border p-2">Phone</th>
          <th className="border p-2">Company</th>
          <th className="border p-2">Department</th>
          <th className="border p-2">Title</th>
        </tr>
      </thead>
      <tbody>
        {users.map((user) => (
          <tr key={user.id}>
            <td className="border p-2 text-blue-600 underline">
              <Link href={`/users/${user.id}`}>
                {user.firstName} {user.lastName}
              </Link>
            </td>
            <td className="border p-2">{user.email}</td>
            <td className="border p-2">{user.phone}</td>
            <td className="border p-2">{user.company.name}</td>
            <td className="border p-2">{user.company.department}</td>
            <td className="border p-2">{user.company.title}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
