import { UsersResponse } from "./user";
import UserTable from "./UserTable";



async function getUsers(): Promise<UsersResponse> {
  const res = await fetch("https://dummyjson.com/users?limit=50", {

  });

  if (!res.ok) {
    throw new Error("Failed to fetch users");
  }

  return res.json();
}

export default async function HomePage() {
  const data = await getUsers();

  return (
    <main className="p-6">
      <h1 className="text-2xl font-semibold mb-4">User List</h1>
      <UserTable users={data.users} />
    </main>
  );
}
