import { User } from "../../user";

interface Props {
  params: Promise<{
    id: string;
  }>;
}

async function getUser(id: string): Promise<User> {
  const res = await fetch(`https://dummyjson.com/users/${id}`, {
    cache: "no-store",
  });

  if (!res.ok) {
    throw new Error("Failed to fetch user");
  }

  return res.json();
}

export default async function UserDetailPage({ params }: Props) {
  const { id } = await params;
  const user = await getUser(id);

  return (
    <main className="p-6 space-y-6">

      <div className="flex items-center gap-4">
        <img
          src={user.image}
          alt={`${user.firstName} ${user.lastName}`}
          className="w-12 h-12 rounded-full border"
        />
        <div className="flex flex-col">
        <h1 className="text-2xl font-semibold">
          {user.firstName} {user.lastName}
        </h1>
          <p>{user.email}</p>
        </div>
      
      </div>

      
      <section>
        <h2 className="font-semibold text-lg mb-2">Basic Information</h2>
        <p><strong>Username:</strong> {user.username}</p>
      
        <p><strong>Phone:</strong> {user.phone}</p>
        <p><strong>Age:</strong> {user.age}</p>
        <p><strong>Gender:</strong> {user.gender}</p>
        <p><strong>Birth Date:</strong> {user.birthDate}</p>
        <p><strong>Role:</strong> {user.role}</p>
      </section>
      <section>
        <h2 className="font-semibold text-lg mb-2">Physical Details</h2>
        <p><strong>Blood Group:</strong> {user.bloodGroup}</p>
        <p><strong>Height:</strong> {user.height} cm</p>
        <p><strong>Weight:</strong> {user.weight} kg</p>
        <p><strong>Eye Color:</strong> {user.eyeColor}</p>
        <p>
          <strong>Hair:</strong> {user.hair.color} ({user.hair.type})
        </p>
      </section>

     
      <section>
        <h2 className="font-semibold text-lg mb-2">Home Address</h2>
        <p>{user.address.address}</p>
        <p>
          {user.address.city}, {user.address.state}{" "}
          ({user.address.stateCode})
        </p>
        <p>{user.address.postalCode}</p>
        <p>{user.address.country}</p>
        <p>
          <strong>Coordinates:</strong> {user.address.coordinates.lat},{" "}
          {user.address.coordinates.lng}
        </p>
      </section>

    
      <section>
        <h2 className="font-semibold text-lg mb-2">Company</h2>
        <p><strong>Name:</strong> {user.company.name}</p>
        <p><strong>Department:</strong> {user.company.department}</p>
        <p><strong>Title:</strong> {user.company.title}</p>

        <h3 className="font-semibold mt-2">Company Address</h3>
        <p>{user.company.address.address}</p>
        <p>
          {user.company.address.city}, {user.company.address.state}{" "}
          ({user.company.address.stateCode})
        </p>
        <p>{user.company.address.postalCode}</p>
        <p>{user.company.address.country}</p>
      </section>

     
      <section>
        <h2 className="font-semibold text-lg mb-2">Other Details</h2>
        <p><strong>University:</strong> {user.university}</p>
        <p><strong>IP Address:</strong> {user.ip}</p>
        <p><strong>MAC Address:</strong> {user.macAddress}</p>
        <p><strong>EIN:</strong> {user.ein}</p>
        <p><strong>SSN:</strong> {user.ssn}</p>
        <p className="break-all">
          <strong>User Agent:</strong> {user.userAgent}
        </p>
      </section>

     
      <section>
        <h2 className="font-semibold text-lg mb-2">Bank Details</h2>
        <p><strong>Card Type:</strong> {user.bank.cardType}</p>
        <p><strong>Card Number:</strong> {user.bank.cardNumber}</p>
        <p><strong>Expiry:</strong> {user.bank.cardExpire}</p>
        <p><strong>Currency:</strong> {user.bank.currency}</p>
        <p className="break-all">
          <strong>IBAN:</strong> {user.bank.iban}
        </p>
      </section>

     
      <section>
        <h2 className="font-semibold text-lg mb-2">Crypto</h2>
        <p><strong>Coin:</strong> {user.crypto.coin}</p>
        <p className="break-all">
          <strong>Wallet:</strong> {user.crypto.wallet}
        </p>
        <p><strong>Network:</strong> {user.crypto.network}</p>
      </section>
    </main>
  );
}
